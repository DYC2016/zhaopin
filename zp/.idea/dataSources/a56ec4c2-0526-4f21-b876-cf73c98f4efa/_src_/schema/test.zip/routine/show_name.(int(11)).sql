CREATE PROCEDURE show_name(IN b INT)
  begin
	select * from a where id=b;
end;
