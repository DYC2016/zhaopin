CREATE TRIGGER trigger_test8
BEFORE INSERT ON test8
FOR EACH ROW
  begin 
insert into trigger_time  values (now());
end;
