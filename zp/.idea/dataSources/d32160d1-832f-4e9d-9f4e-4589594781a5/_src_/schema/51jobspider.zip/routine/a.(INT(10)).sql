CREATE PROCEDURE a(IN a INT(10))
  BEGIN
select * from 51jobs_all;
end;
